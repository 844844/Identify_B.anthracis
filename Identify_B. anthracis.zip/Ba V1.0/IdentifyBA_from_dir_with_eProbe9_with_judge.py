#!/usr/bin/env python3
# -*- coding:utf-8 -*-
eProbe_TagFile = open("eProbe9.txt",'r')

mydict={}
for line in eProbe_TagFile:
    line = line.strip()
    site,pos,tag=line.split("\t")
    tagR = ''
    for base in reversed(tag):
        tagR += base
    table = tagR.maketrans("[]ATGC","][TACG")
    tagRC = tagR.translate(table)
    mydict[site] =[pos,tag,tagRC]
    
eProbe_TagFile.close()

list(mydict.values())


import os
import re
mydir="./test_data_Bcgroup/"
myout = open("Result_identify_BA.txt",'w')
mystr="Strains\tBa813_Ba\tcrispR5_Ba1\tcrispR5_Ba2\tplcR_Ba\tpurA_Ba\tpyc_Ba\trpoB_Ba\tSG850_Ba\ttpiA_Ba\tBa813_Bct\tcrispR5_Bct1\tcrispR5_Bct2\tplcR_Bct\tpurA_Bct\tpyc_Bct\trpoB_Bct\tSG850_Bct\ttpiA_Bct\tIs_B.anthracis\n"
myout.write(mystr)

for root,dirs,files in os.walk(mydir):
    for file in files:
        myout.write(file+"\t")
        seq=''
        infile=open(os.path.join(root,file),'r')
        for line in infile:
            line=line.strip()
            if not line.startswith(">"):
                seq += line
        infile.close()
        SNPtype_list=[]
        
        for Site,Tags in mydict.items():
            [pos,tag,tagRC] = Tags
            pos = int(pos)
            mytag=''
            SNPtype=''
            
            if re.search(tag,seq) or re.search(tagRC,seq):
                if re.search(tag,seq):
                    result = re.search(tag,seq)
                    mytag = result.group()
                elif re.search(tagRC,seq):
                    result = re.search(tagRC,seq)
                    Match = result.group()
                    MatchR = Match[::-1]
                    table = MatchR.maketrans("ATGC","TACG")
                    mytag =MatchR.translate(table)
                SNPtype = mytag[pos]
            else:
                SNPtype="-"
            SNPtype_list.append(SNPtype)
        IsBA="No"
        for base in SNPtype_list[:9]:
            if base !="-":
                IsBA="Yes"
                break
        SNPtype_list.append(IsBA)
        myout.write("\t".join(SNPtype_list)+"\n")
myout.close()       
            
                    
